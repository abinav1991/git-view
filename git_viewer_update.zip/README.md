## GitViewer UI

Frontend application for GitViewer app.

#### Install dependencies

* Install dependencies: `npm`, `node`

#### Start developing

`npm install`
`npm start`
