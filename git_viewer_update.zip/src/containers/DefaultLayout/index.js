import DefaultLayout from './DefaultLayout';

export default DefaultLayout;
