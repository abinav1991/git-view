export let apiEndPoint = 'https://api.github.com';

export let gitClientId = '1915211a80d51ca24b44';

export let gitClientSecret = 'a8db800bb923fe5858975fd443bb4230553856f5';
